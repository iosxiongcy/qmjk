//
//  CYTools.h
//  蓝牙demo
//
//  Created by 深圳前海全民健康科技股份有限公司 on 2017/6/2.
//  Copyright © 2017年 深圳前海全民健康科技股份有限公司. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CYBTTools : NSObject


/**
 两种16进制字符串转NSData的方法
 */
+ (NSData *)hexToBytes:(NSString *)str;
+ (NSData *)dataFromHexString:(NSString *)hexString;



/**
 16进制字符串 -> 10进制字符串 -> （通过ASCII码）转换成字符串
 */
+ (NSString *)stringWithHexString:(NSString *)hexstring;

/**
 去掉字符串中所有的大小写字母和空格并转换成int类型
 */
+ (int)intValueWithString:(NSString *)string;

/**
 根据16进制字符串获取设备id
 */
+ (NSString *)getDeviceIdWithHexString:(NSString *)dataStr;
/**
 从本地zip中获取md5
 */
+ (NSString *)getFileMD5:(NSString *)path;

@end
