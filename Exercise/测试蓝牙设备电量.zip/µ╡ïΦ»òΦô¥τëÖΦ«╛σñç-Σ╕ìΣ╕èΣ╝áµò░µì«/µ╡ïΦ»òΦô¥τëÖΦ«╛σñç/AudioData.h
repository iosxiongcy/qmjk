//
//  AudioData.h
//  GeneralHealth15
//
//  Created by Liu  on 2016/11/26.
//  Copyright © 2016年 shiyc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>
@interface AudioData : NSObject
+(NSMutableArray *)Zhuanhuan:(NSMutableArray *)jiexidata;
+(NSMutableArray *)Jiexi:(NSMutableArray *)jiexidata;
+ (NSMutableArray *)toDecimalSystemWithBinarySystem:(NSString *)binary;
//判断录音权限
+ (BOOL)TestLuYin;


//获取手机信息
+ (NSMutableDictionary *)GetPhoneInfo;

+ (NSString*)deviceVersion;
+ (NSString *)getTotalMemorySize;
//秒数转时间
+ (NSString *)ConvertStrToTime:(long long)timeStr;
//比较时间
+ (NSString*)compareTwoTime:(long long)time1 time2:(long long)time2;
//获取当前时间
+ (NSString *)getNowTime;
//时间转秒
+ (long long)timeToSecond:(NSString *)time;
//获取当前网络ip
+ (NSString *)deviceIPAdress;
//获取公网ip
+(NSString *)deviceWANIPAddress;



// 16进制字符串转10进制数
+ (NSNumber *)numberHexString:(NSString *)aHexString;


/**
 把蓝牙传过来的16进制数据转换成10进制数组
 
 @param dataStr 16进制数 字符串
 @return 10进制数组
 */
+ (NSMutableArray *)bluetoothDataWithHexString:(NSString *)dataStr;
/**
 中值滤波
 */
+ (NSMutableArray *)arrayWithResult:(NSNumber *)r arr:(NSMutableArray *)tempArr;

//数组或字典转json字符串
+ (NSString *)jsonStringWithObj:(id)obj;


//+ (void)test:(NSData *)data;

@end

