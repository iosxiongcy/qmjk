//
//  AudioData.m
//  GeneralHealth15
//
//  Created by Liu  on 2016/11/26.
//  Copyright © 2016年 shiyc. All rights reserved.
//

#import "AudioData.h"
#import <math.h>
#import "sys/utsname.h"
#import <sys/mount.h>//从底层直接获取手机版本的相关的型号和信息
#import <ifaddrs.h>
#import <arpa/inet.h>
#import <UIKit/UIKit.h>
#import "DecimalConvertUtils.h"

static int _k;
static int _testK;
static NSString * _lastObjectStr;
static NSArray * _lastObjectArr;

@interface AudioData ()

@end

@implementation AudioData
+(NSMutableArray *)Zhuanhuan:(NSMutableArray *)jiexidata {
    NSMutableArray *arr = [[NSMutableArray alloc]init];
    NSMutableArray *nowArr = [[NSMutableArray alloc]init];
    NSMutableArray *saveArr = [[NSMutableArray alloc]init];
    NSMutableArray *endArr = [[NSMutableArray alloc]init];
    //    NSLog(@"111");
    //区分正负,把负数全都置为0,正数和0全部置为1
    //从音频口调用的原始数据有正数和负数的区分
    //    NSDateFormatter * formatter = [[NSDateFormatter alloc ] init];
    //    //[formatter setDateFormat:@"YYYY.MM.dd.hh.mm.ss"];
    //    [formatter setDateFormat:@"YYYY-MM-dd hh:mm:ss:SSS"];
    //    //方法的上下打印当前的时间节点
    //    NSString * date3 = [formatter stringFromDate:[NSDate date]];
    //    NSString * timeNow3 = [[NSString alloc] initWithFormat:@"%@", date3];
    //
    //    NSLog(@"时间3  %@",timeNow3);
    for (int i = 0; i < jiexidata.count; i ++) {
        float f = [jiexidata[i]intValue];
        
        //        printf("%f\n",f);
        
        int num = f>=0?1:0;//num 0 1 高低电平
        [arr addObject:[NSNumber numberWithInt:num]];
    }
    //  NSString * date4 = [formatter stringFromDate:[NSDate date]];
    //    NSString * timeNow4 = [[NSString alloc] initWithFormat:@"%@", date4];
    //
    //    NSLog(@"时间4  %@",timeNow4);
    //    NSLog(@"2222");
    for (int i = 0 ; i < arr.count; i ++) {//45000
        [nowArr addObject:arr[i]];
        
        //跟下一个数比较,把处理过的连续的1存数组,全部的0存数组
        
        //        if (i<arr.count-1 && arr[i]!=arr[i+1]) {
        //            [saveArr addObject:[NSArray arrayWithArray:nowArr]];//分别保存高低电平 1 0
        //            _testK+=nowArr.count;
        //            [nowArr removeAllObjects];
        //        }
        //
        if (i<arr.count-1 ) {
            if (arr[i]!=arr[i+1]) {
                [saveArr addObject:[NSArray arrayWithArray:nowArr]];//分别保存高低电平 1 0
                _testK+=nowArr.count;
                [nowArr removeAllObjects];
            }
        }
        //        else
        //        {
        //            if (arr[i]==arr[i-1]) {
        //                [saveArr addObject:[NSArray arrayWithArray:nowArr]];
        //                _testK+=nowArr.count;
        //                [nowArr removeAllObjects];
        //            }
        //            else{
        //
        //                [saveArr addObject:[NSArray arrayWithObject:arr[i]]];
        //                _testK++;
        //            }
        //        }
    }
    //    NSString * date5 = [formatter stringFromDate:[NSDate date]];
    //    NSString * timeNow5 = [[NSString alloc] initWithFormat:@"%@", date5];
    //
    //    NSLog(@"时间5  %@",timeNow5);
    //     NSLog(@"%@",saveArr);
    //    NSLog(@"333");
    //调用解析
    //    printf("   %d\n",_testK);
    _testK = 0;
    
    [endArr addObjectsFromArray:[self Jiexi:saveArr]];
    //    NSLog(@"444");
    //在endArr中 取得每次解析后的数组中最后一个对象 为不足32位或者大于32位的数据进行补位
    _lastObjectArr = [endArr lastObject];
    //    NSLog(@"%@",_lastObjectArr[1]);
    
    //    NSLog(@"%ld",endArr.count);
    return endArr;
}
/*
 *
 continue 结束本次循环    break 结束整个循环  下面的代码是新逻辑
 *
 */
#pragma mark 2017-06-22 逻辑重构 wsx 首先确认解析是没有问题的，但是丢点16个
+(NSMutableArray *)Jiexi:(NSMutableArray <NSArray *>*)jiexidata
{
//    int num = 0;//可以不用
//    int num1 = 0;//找到一个起始位 ++
    int index = 0;//记录当前开始解析的位
    BOOL canjiexi = NO;//记录是否可以解析，找到起始位之后
    
    int weishu = 0;//32位 记录
    int weishucount = 0; //记录每一个位数的个数
    NSString *str = @"";//记录解析后的32位 16进制数
    NSMutableArray * outArr = [[NSMutableArray alloc]init];//保存解析好的数据
    
    //kuandu就是当解析为高电平1的时候,是由2段组成,等于2组数为一个完整的高电平1,这个kuandu就是记这个高电平1的够不够完整
    int kuandu = 0;
    /**开始解析**/
    for (int i=1; i<jiexidata.count; i++) {//i=1 开始为了当前为起始位开始的长电平 i-2  好标记起始位
        /**寻找起始位
         规则：i 当前点数大于16点，i+1点数在3-5之间 i<jiexidata.count 为了去除开始解析的点，起始位点，这样才算开始起始位
         **/
        if (i<jiexidata.count-2 &&jiexidata[i].count>16&&(jiexidata[i+1].count>=3)&&jiexidata[i+1].count<=5) {
            index = i+2;//标记开始解析位
        }
        //是否可以解析参数判断
        if (index==i) {
            canjiexi = YES;
        }
        // canjiexi==YES 开始记录解数据
        /**注意⚠️
         什么时候补位:当outArr.count>=2(说明outArr[i]前面还有数据，可以补位) outArr[i]解析数据不
         足32位 补位outArr[i-1],outArr[i]解析大于32位 补位outArr[i-1]
         **/
        if (canjiexi) {//找到起始位,可以解析
            
            if (weishu<32) {//分正好 31位，小于31位⚠️解析完成的数据补位在小于32位，大于32位中
                //小于31位的数据进行补位 没有实现，判断逻辑错误!
                
                if (i+1 >=jiexidata.count) {//数据位解析完成，没有到32位
                    
                    //                    if (outArr.count>=2) {//数组数量大于才有能力补位
                    //
                    //                    [outArr addObject:outArr[i-1]];
                    //                    [outArr addObject:outArr[i-1]];
                    
                    //                        }
                    //
                    //                     [outArr addObject:outArr[i-1]];
                    //                    NSLog(@"补位啊！--------------");
                    //                    NSLog(@"补位数组位%@",outArr[i-1]);
                    //清空数据
                    str = @"";
                    weishu = 0;
                    weishucount = 0;
                    canjiexi = NO;
                    continue;//跳出本次循环
                }
                //解32位
                if (weishu==31) {//强制32位
                    if (jiexidata[i].count>11) {//第32位判断
                        str = [NSString stringWithFormat:@"0%@",str];
                    }
                    else if (jiexidata[i].count<7 &&jiexidata[i+1].count>11){
                        str = [NSString stringWithFormat:@"1%@",str];
                    }
                    //16进制转10进制 返回事实数组数据 outStr[0] 红光 outStr[1] 红外光
                    
                    NSMutableArray * outStr = [self toDecimalSystemWithBinarySystem:str];
                    
                    //                    [outArr addObject:outStr];
                    [outArr addObjectsFromArray:outStr];
                    
                    //清空数据,跳出本次循环
                    index = 0;
                    str = @"";
                    weishu = 0;
                    weishucount = 0;
                    canjiexi = NO;
                    continue;
                }
                else{
                    //                    else{
                    //解析 0-31位 通用的模式
                    // 高电平1 低电平0 特殊点数判断
                    if (jiexidata[i].count==7 &&kuandu==0) {//数组中的点数为 7 特殊处理
                        //由图形判断，当前点数为7 后一位大于4的话，当前为低电平 0
                        if ((jiexidata[i].count + jiexidata[i+1].count)>11) {
                            str = [NSString stringWithFormat:@"0%@",str];
                            weishu ++;
                        }else{//半个高电平 1
                            kuandu ++;
                        }
                    }
                    //低电平 0 的通用判断
                    if (jiexidata[i].count>7 &&jiexidata[i].count<=11) {
                        str = [NSString stringWithFormat:@"0%@",str];
                        weishu++;
                    }
                    //高电平 1 的通用判断
                    if (jiexidata[i].count>=2 && jiexidata[i].count<7) {
                        //开始进来 半个高电平 宽度 +1
                        kuandu ++;
                        if (kuandu==2) {//宽度为 2 组成一个高电平 1
                            str = [NSString stringWithFormat:@"1%@",str];
                            weishu++;
                            kuandu = 0;//找到高电平 1 清空记录宽度
                        }
                    }
                    //                    }
                    /****段位***/
                }
            }else{//位数大于32位，放弃解析，继续循环
                //加入前一个数组数据(相当于每次解的最后一个数据位)
//                printf("超过32位用前一位补位!");
                [outArr addObject:outArr[i-1]];
                index = 0;
                str = @"";
                weishu = 0;
                weishucount = 0;
                canjiexi = NO;
                continue;
            }
        }
    }
    return outArr;
}
#pragma mark 2017-6-19 wang解析数据
//  二进制转十进制 打印红外光值
+(NSMutableArray *)toDecimalSystemWithBinarySystem:(NSString *)binary
{
    //    NSLog(@"好尴尬!");
    
    
    //    NSDateFormatter * formatter = [[NSDateFormatter alloc ] init];
    //    //[formatter setDateFormat:@"YYYY.MM.dd.hh.mm.ss"];
    //    [formatter setDateFormat:@"YYYY-MM-dd hh:mm:ss:SSS"];
    //    //方法的上下打印当前的时间节点
    //    NSString * date3 = [formatter stringFromDate:[NSDate date]];
    //    NSString * timeNow3 = [[NSString alloc] initWithFormat:@"%@", date3];
    //
    //    NSLog(@"时间3  %@",timeNow3);
    
    NSMutableArray *outArr = [[NSMutableArray alloc]init];
    NSString *str1 = [binary substringToIndex:16];
    NSString *str2 = [binary substringFromIndex:16];
    //    NSLog(@"str1===%@,str2===%@",str1,str2);
    
    //并列的两个循环解析红光／红外光数据
    
//    int  lRed = 0;
//    int lIred = 0;
//    int redTemp = 0;
//    int iRedTemp = 0;
    
    //    for (int j = 0; j < str1.length; j ++)
    //    {
    //        redTemp = [[str1 substringWithRange:NSMakeRange(j, 1)] intValue];
    //        redTemp = redTemp * powf(2, str1.length - j - 1);
    //        lRed += redTemp;
    //    }
    //    for (int k = 0; k < str2.length; k ++)
    //    {
    //        iRedTemp = [[str2 substringWithRange:NSMakeRange(k, 1)] intValue];
    //        iRedTemp = iRedTemp * powf(2, str2.length - k - 1);
    //        lIred += iRedTemp;
    //    }
    //    printf("解析%d-%d\n",_k,lIred);
    //    //将打印的10进制红光，红外光放到数组中
    //    NSArray * arr = [NSArray arrayWithObjects:[NSNumber numberWithInt:lRed],[NSNumber numberWithInt:lIred], nil];
    //    [outArr addObjectsFromArray:arr];
    
    
    
    
    
    NSArray *arr = [NSArray arrayWithObjects:str1,str2, nil];
    for (int i = 0; i < arr.count; i ++) {
        int ll = 0 ;
        int  temp = 0 ;
        NSString *str = arr[i];
        
        
        for (int j = 0; j < str.length; j ++)
        {
            temp = [[str substringWithRange:NSMakeRange(j, 1)] intValue];
            temp = temp * powf(2, str.length - j - 1);
            ll += temp;
        }
        
        
        //打印解析出的红光红外光
        if (ll != 3000) {
            //            NSLog(@"cuowu : %@",binary);
            if (ll>64000) {
                //                NSLog(@"================================%d",ll);
            }else {
                if (i==0) {//==1红光  ==0 红外
                    //                    NSLog(@"解析%d\n",ll);//每一个值
#pragma mark 有用
//                    printf("解析%d-%d\n",_k,ll);
                    //                      printf("%d\n",ll);
                    //第一次 1 - ll  2-ll 3
                }
            }
        }else {
            //            NSLog(@"%d",ll);
        }
        
        [outArr addObject:[NSNumber numberWithInt:ll]];
    }
    _k++;
    //    //方法的上下打印当前的时间节点
    //    NSString * date4 = [formatter stringFromDate:[NSDate date]];
    //    NSString * timeNow4 = [[NSString alloc] initWithFormat:@"%@", date4];
    //
    //    NSLog(@"时间4  %@",timeNow4);
    //    NSLog(@"2017-06-08打印出解析数据的个数为+++%ld",outArr.count);
    return outArr;
}

////////////////////////////////////////////////////
////////////////////////////////////////////////////
////////////////////////////////////////////////////
////////////////////////////////////////////////////
//获取手机信息
+ (NSMutableDictionary *)GetPhoneInfo {
    NSMutableDictionary *dic = [[NSMutableDictionary alloc]init];
    NSString *iosVersion = [[UIDevice currentDevice]systemVersion];
    NSString *phoneVersion = [AudioData deviceVersion];
    NSString *phoneMemory = [AudioData getTotalMemorySize];
//    NSLog(@"ios版本：%@，手机版本：%@，手机内存：%@",iosVersion,phoneVersion,phoneMemory);
    [dic setValue:iosVersion forKey:@"androidVersion"];
    [dic setValue:phoneVersion forKey:@"phoneModel"];
    [dic setValue:phoneMemory forKey:@"phoneMemory"];
    return dic;
}
+ (NSString *)getTotalMemorySize
{
    long long num = [NSProcessInfo processInfo].physicalMemory;
//    NSLog(@"%lld",num);
    float num1 = num/1024.0/1024.0/1024.0;
//    NSLog(@"%f",num1);
    NSString *num2 = [NSString stringWithFormat:@"%d",(int)(num1+0.5)];
    return  num2;
}
+ (NSString*)deviceVersion
{
    // 需要#import "sys/utsname.h"
    struct utsname systemInfo;
    uname(&systemInfo);
    NSString * deviceString = [NSString stringWithCString:systemInfo.machine encoding:NSUTF8StringEncoding];
    //iPhone
    //    if ([deviceString isEqualToString:@"iPhone1,1"])    return @"iPhone 1G";
    //    if ([deviceString isEqualToString:@"iPhone1,2"])    return @"iPhone 3G";
    //    if ([deviceString isEqualToString:@"iPhone2,1"])    return @"iPhone 3GS";
    //    if ([deviceString isEqualToString:@"iPhone3,1"])    return @"iPhone 4";
    //    if ([deviceString isEqualToString:@"iPhone3,2"])    return @"Verizon iPhone 4";
    //    if ([deviceString isEqualToString:@"iPhone4,1"])    return @"iPhone 4S";
    //    if ([deviceString isEqualToString:@"iPhone5,1"])    return @"iPhone 5";
    //    if ([deviceString isEqualToString:@"iPhone5,2"])    return @"iPhone 5";
    //    if ([deviceString isEqualToString:@"iPhone5,3"])    return @"iPhone 5C";
    //    if ([deviceString isEqualToString:@"iPhone5,4"])    return @"iPhone 5C";
    //    if ([deviceString isEqualToString:@"iPhone6,1"])    return @"iPhone 5S";
    //    if ([deviceString isEqualToString:@"iPhone6,2"])    return @"iPhone 5S";
    //    if ([deviceString isEqualToString:@"iPhone7,1"])    return @"iPhone 6 Plus";
    //    if ([deviceString isEqualToString:@"iPhone7,2"])    return @"iPhone 6";
    //    if ([deviceString isEqualToString:@"iPhone8,1"])    return @"iPhone 6s";
    //    if ([deviceString isEqualToString:@"iPhone8,2"])    return @"iPhone 6s Plus";
    //    if ([deviceString isEqualToString:@"iPhone8,4"])    return @"iPhone SE";
    //    if ([deviceString isEqualToString:@"iPhone9,1"])    return @"iPhone 7";
    //    if ([deviceString isEqualToString:@"iPhone9,2"])    return @"iPhone 7 Plus";
    return deviceString;
}
+ (NSString *)ConvertStrToTime:(long long)timeStr {
    
    NSDate *d = [[NSDate alloc]initWithTimeIntervalSince1970:timeStr/1000.0];
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
    
    [formatter setDateFormat:@"yyyy-MM-dd"];
    
    NSString*timeString=[formatter stringFromDate:d];
    
    return timeString;
    
}

+ (NSString*)compareTwoTime:(long long)time1 time2:(long long)time2
{
    NSTimeInterval balance = time2 - time1 ;
    NSString*timeString = [[NSString alloc]init];
    timeString = [NSString stringWithFormat:@"%f",balance /60];
    timeString = [timeString substringToIndex:timeString.length-7];
    NSInteger timeInt = [timeString intValue];
    NSInteger hour = timeInt /60;
    NSInteger mint = timeInt %60;
    
    if(hour ==0) {
        timeString = [NSString stringWithFormat:@"%ld分钟",(long)mint];
    }
    else
    {
        if(mint ==0) {
            timeString = [NSString stringWithFormat:@"%ld小时",(long)hour];
        }
        else
        {
            timeString = [NSString stringWithFormat:@"%ld小时%ld分钟",(long)hour,(long)mint];
        }
    }
    return timeString;
}

+ (NSString *)getNowTime {
    NSDate *currentDate = [NSDate date];//获取当前时间，日期
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSString *dateString = [dateFormatter stringFromDate:currentDate];
    return dateString;
}
//将年月日的时间转化为秒的形式
+ (long long)timeToSecond:(NSString *)time {
    NSDateFormatter * formatter = [[NSDateFormatter alloc]init];
    [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];//年－月－日 格式
    NSDate * oldDate = [formatter dateFromString:time];
    //将NSDate 转化为秒
    NSTimeInterval interval = [oldDate timeIntervalSince1970];
//    NSLog(@"转换的时间戳=%f",interval);
    //long long totalMilliseconds = interval*1000 ;
    
    //减去七天的秒数据
    long long newDateSeconds = interval;
    return newDateSeconds;
}
+ (NSString *)deviceIPAdress {
    NSString *address = @"an error occurred when obtaining ip address";
    struct ifaddrs *interfaces = NULL;
    struct ifaddrs *temp_addr = NULL;
    int success = 0;
    success = getifaddrs(&interfaces);
    if (success == 0) { // 0 表示获取成功
        temp_addr = interfaces;
        while (temp_addr != NULL) {
            if( temp_addr->ifa_addr->sa_family == AF_INET) {
                // Check if interface is en0 which is the wifi connection on the iPhone
                if ([[NSString stringWithUTF8String:temp_addr->ifa_name] isEqualToString:@"en0"]) {
                    // Get NSString from C String
                    address = [NSString stringWithUTF8String:inet_ntoa(((struct sockaddr_in *)temp_addr->ifa_addr)->sin_addr)];
                }
            }
            
            temp_addr = temp_addr->ifa_next;
        }
    }
    freeifaddrs(interfaces);
    return address;
}

+(NSString *)deviceWANIPAddress
{
    NSURL *ipURL = [NSURL URLWithString:@"http://ip.taobao.com/service/getIpInfo.php?ip=myip"];
    NSData *data = [NSData dataWithContentsOfURL:ipURL];
    NSDictionary *ipDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
    return (ipDic[@"data"][@"ip"] ? ipDic[@"data"][@"ip"] : @"");
}
////////////////////////////////////////////////////
////////////////////////////////////////////////////
////////////////////////////////////////////////////
////////////////////////////////////////////////////



//判断录音权限
+ (BOOL)TestLuYin {
    AVAuthorizationStatus videoAuthStatus = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeAudio];
    if (videoAuthStatus == AVAuthorizationStatusNotDetermined) {// 未询问用户是否授权
        return NO;
    }else if(videoAuthStatus == AVAuthorizationStatusRestricted || videoAuthStatus == AVAuthorizationStatusDenied) {// 未授权
        return NO;
    }else{// 已授权
        return YES;
    }
}

// 16进制转10进制
+ (NSNumber *)numberHexString:(NSString *)aHexString
{
    // 为空,直接返回.
    if (nil == aHexString)
    {
        return nil;
    }
    
    NSScanner * scanner = [NSScanner scannerWithString:aHexString];
    unsigned long long longlongValue;
    [scanner scanHexLongLong:&longlongValue];
    
    //将整数转换为NSNumber,存储到数组中,并返回.
    NSNumber * hexNumber = [NSNumber numberWithLongLong:longlongValue];
    
    return hexNumber;
    
}

+ (NSMutableArray *)bluetoothDataWithHexString:(NSString *)dataStr {
    NSMutableArray *newArr = [NSMutableArray array];
    
    dataStr = [dataStr stringByReplacingOccurrencesOfString:@" " withString:@""];
    dataStr = [dataStr stringByReplacingOccurrencesOfString:@">" withString:@""];
    // 1fff19 1fff19 1fff19 1fff19 1fff19 1fff19 0596---length:40
    dataStr = [dataStr stringByReplacingOccurrencesOfString:@"<" withString:@""];
    
    dataStr = [dataStr substringFromIndex:4];
    
    for (int i = 0; i < dataStr.length; i ++) {
        NSNumber *result = [[NSNumber alloc] init];
        // 每隔6位取一次16进制数 （6位的16进制数）  65535
        // 第一次取的为红外值，第二次取的为红光值，第三次红外，第四次红光，依次类推
        
        if (i == 5 || i == 17 || i == 29) {
            NSString *ired = [dataStr substringWithRange:NSMakeRange(i - 5, 6)];
//            ired = [self handleHex:ired];
            // 红外值
//            result = [self numberMul32HexString:ired];
            result = [self handleHex:ired];
        }
        if (i == 11 || i == 23 || i == 35) {
            NSString *red = [dataStr substringWithRange:NSMakeRange(i - 5, 6)];
//            red = [self handleHex:red];
            // 红光值
//            result = [self numberMul32HexString:red];
            result = [self handleHex:red];
        }
        
        // 数据包
        if (i == 39) {
            //            result = [self numberHexString:[dataStr substringWithRange:NSMakeRange(i - 3, 4)]];
        }
        
        if (result) {
            [newArr addObject:result];
        }
    }
    
    return newArr;
}

// 每从夹子取出一个数据,就放到临时数组中,存够5个开始从小到大排序,取出中间数据返回
// 然后去掉最小的数据,继续添加新的数据进去,重复上面的操作
+ (NSMutableArray *)arrayWithResult:(NSNumber *)r arr:(NSMutableArray *)tempArr {
//    NSMutableArray *tempArr = isRed? _tempRedArr : _tempIRedArr;
    
//    NSNumber *result = [[NSNumber alloc] init];
    if (r) {
        [tempArr addObject:r];
    }
    if (tempArr.count<5) {
        return nil;
    }
    // 从小到大排序
    [tempArr sortUsingComparator:^NSComparisonResult(id  _Nonnull obj1, id  _Nonnull obj2) {
        if ([obj1 integerValue] > [obj2 integerValue]) {
            return (NSComparisonResult)NSOrderedDescending;
        }
        if ([obj1 integerValue] < [obj2 integerValue]) {
            return (NSComparisonResult)NSOrderedAscending;
        }
        return (NSComparisonResult)NSOrderedSame;
    }];
//    result = tempArr[2];
//    [tempArr removeObjectAtIndex:0];

    
    return tempArr;
}

// 16进制转10进制 结果除以32
+ (NSNumber *)numberMul32HexString:(NSString *)aHexString
{
    // 为空,直接返回.
    if (nil == aHexString)
    {
        return nil;
    }
    
    NSScanner * scanner = [NSScanner scannerWithString:aHexString];
    unsigned long long longlongValue;
    [scanner scanHexLongLong:&longlongValue];
    
    //将整数转换为NSNumber,存储到数组中,并返回.
    NSNumber * hexNumber = [NSNumber numberWithLongLong:longlongValue/32];
    
    return hexNumber;
    
}

//数组或字典转json字符串
+ (NSString *)jsonStringWithObj:(id)obj {
    if (!obj) {
        return nil;
    }
    NSError *error = [NSError errorWithDomain:@"com.xiongcy.qmjk.sdk" code:520 userInfo:@{@"errorMsg":@"数组/字典转json字符串时发生错误"}];
    NSData *data=[NSJSONSerialization dataWithJSONObject:obj options:NSJSONWritingPrettyPrinted error:&error];
    NSString *jsonStr=[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
//    NSLog(@"%@",error);
    return jsonStr;
}

// 返回的是10进制  结果除以32
+ (NSNumber *)handleHex:(NSString *)hexString {
    // 3fffff
    NSString *result = @"";
    
    // 16进制->2进制
    NSString *binary = [DecimalConvertUtils toBinaryWithHex:hexString];
//    NSLog(@"完整的二进制字符串:%@", binary);
    
    // 第3个字符为符号位
    NSString *symbol = [binary substringWithRange:NSMakeRange(2, 1)];
//    NSLog(@"符号位:%@", symbol);
    
    // 如果符号位为0,返回hexString
    if ([symbol isEqualToString:@"0"]) {
        return [NSNumber numberWithInt:[[DecimalConvertUtils numberHexString:hexString] intValue] / 32];
    } else if ([symbol isEqualToString:@"1"]) {
        // 如果符号位为1, 补码转原码
//        result = [binary substringToIndex:3];
        binary = [binary substringFromIndex:3];
//        NSLog(@"前三位数:%@", result);
        binary = [DecimalConvertUtils binaryAdd1:binary];
//        result = [NSString stringWithFormat:@"%@%@", result, binary];
    }
//    NSLog(@"最终二进制:%@", binary);
    result = [DecimalConvertUtils toDecimalWithBinary:binary];
//    NSLog(@"最终16进制:%@", result);
    return [NSNumber numberWithInt:-[result intValue] / 32];
}

@end
