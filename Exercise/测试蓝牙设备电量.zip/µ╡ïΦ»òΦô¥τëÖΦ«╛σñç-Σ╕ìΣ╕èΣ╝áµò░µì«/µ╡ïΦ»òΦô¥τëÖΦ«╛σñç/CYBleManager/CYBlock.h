//
//  CYBlock.h
//  CYBluetoothManager
//
//  Created by 深圳前海全民健康科技股份有限公司 on 2017/9/8.
//  Copyright © 2017年 深圳前海全民健康科技股份有限公司. All rights reserved.
//

#ifndef CYBlock_h
#define CYBlock_h

typedef enum : NSUInteger {
    CYBleManagerConnecting,
    CYBleManagerConnected,
    CYBleManagerConnectFail,
    CYBleManagerConnectTimeout,
    CYBleManagerDisconnecting,
    CYBleManagerDisconnected,           // 手动断开蓝牙连接
    CYBleManagerDisconnectAccident      // 意外断开蓝牙连接
} CYBleManagerConnectState;

typedef enum : NSUInteger {
    CYDFUStateStart,
    CYDFUStateFail,
    CYDFUStateUpdating,
    CYDFUStateCompleted,
} CYDFUState;

// 连接状态
typedef void(^CYBleManagerConnect)(CYBleManagerConnectState state);

// 向特征写数据
typedef void(^CYBleManagerWriteResponse)(NSData *data);

// 从特征读数据
typedef void(^CYBleManagerReadValueResponse)(NSData *data);

// 扫描到的蓝牙设备
typedef void(^CYBleManagerPeripherals)(NSArray <CBPeripheral *> *peripherals);



#endif /* CYBlock_h */
