//
//  ViewController.m
//  测试蓝牙设备
//
//  Created by 深圳前海全民健康科技股份有限公司 on 2017/10/13.
//  Copyright © 2017年 深圳前海全民健康科技股份有限公司. All rights reserved.
//

#import "ViewController.h"

#import "CYBleManager.h"
#import "AudioData.h"

@interface ViewController () <UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UILabel *logLabel;

@property (nonatomic, strong) CYBleManager *bleManager;

@property (nonatomic, strong) CBCharacteristic *read;

@property (nonatomic, strong) CBCharacteristic *write;

@property (nonatomic, assign) int index;
@property (nonatomic, strong) NSMutableArray *powers;
@property (nonatomic, strong) NSMutableArray *voltages;  // 电压值
@property (nonatomic, strong) NSMutableArray *times;
@property (nonatomic, strong) NSMutableArray *indexs;

@property (nonatomic, strong) CBPeripheral *peripheral;

@property (weak, nonatomic) IBOutlet UITextField *perName;

/**
 测量时间 1min
 */
@property (nonatomic, assign) int testTime;
@property (nonatomic, strong) NSTimer *testTimer;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _powers = [NSMutableArray array];
    _voltages = [NSMutableArray array];
    _times = [NSMutableArray array];
    _indexs = [NSMutableArray array];
    _bleManager = [CYBleManager manager];
    _bleManager.isAutoConnect = NO;
    _testTimer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(stopTest) userInfo:nil repeats:YES];
    [_testTimer fire];
    
    
}

- (IBAction)start:(UIButton *)sender {
    if (!_perName.text.length) {
        [self showAlertControllerWithMessage:@"请输入蓝牙名称" isBack:NO];
        return;
    }
    
    _perName.enabled = NO;
    [_perName resignFirstResponder];
    sender.enabled = NO;
    [self scan];
    [self moniterState];
}

- (void)scan {
    _index ++;
    _logLabel.text = @"正在搜索设备...";
    [_indexs addObject:[NSNumber numberWithInt:_index]];
    [_bleManager startScan:5 services:nil isFilter:YES result:^(NSArray<CBPeripheral *> *peripherals) {
        for (CBPeripheral *per in peripherals) {
            NSLog(@"%@", per.name); // @"cooya hr 1-z03w"
            if ([per.name isEqualToString:_perName.text]) { // z03u  z03w   z03v
                _peripheral = per;
            }
        }
    }];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (!_peripheral) {
            _logLabel.text = @"设备不存在!";
            return ;
        }
        [_bleManager connectBle:_peripheral timeout:10];
    });
}

- (void)moniterState {
    [_bleManager moniterBleConnectState:^(CYBleManagerConnectState state) {
        switch (state) {
            case CYBleManagerConnected:
            {
                // 连接成功
                _logLabel.text = [NSString stringWithFormat:@"连接上设备--%@", _bleManager.peripheral.name];
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    NSArray *arr = _bleManager.characters.allValues;
//                    NSLog(@"%@", arr);
                    for (NSArray *items in arr) {
                        for (NSObject *obj in items) {
                            if ([obj isKindOfClass:[CBCharacteristic class]]) {
                                CBCharacteristic *c = (CBCharacteristic *)obj;
                                if ([c.UUID.UUIDString isEqualToString:@"1524"]) {
                                    // 读特征
                                    _read = c;
                                } else if ([c.UUID.UUIDString isEqualToString:@"1525"]) {
                                    // 写特征
                                    _write = c;
                                }
                                
                            }
                        }
                    }
                    
                    [self startTest];
                });
            }
                break;
            case CYBleManagerConnecting:
            {
                // 连接中
            }
                break;
            case CYBleManagerConnectFail:
            {
                // 连接失败
            }
                break;
            case CYBleManagerDisconnected:
            {
                // 断开连接
                _logLabel.text = @"设备断开连接";
                
                // 3min钟之后自动连接, 并且开始测量 3 * 60
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(60 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    [self scan];
                });
            }
                break;
            case CYBleManagerDisconnecting:
            {
                // 断开连接中
            }
                break;
            case CYBleManagerConnectTimeout:
            {
                // 连接超时
            }
                break;
            case CYBleManagerDisconnectAccident:
            {
                // 意外断开
            }
                break;
                
            default:
                break;
        }
    }];
}

- (void)startTest {
    if (!_read || !_write) {
        _logLabel.text = @"特征值读取失败";
        return ;
    }
    // 开启使能
    [_bleManager setNotify:YES forCharacter:_read];
    _logLabel.text = @"开启使能成功";
    
    // 获取电量
    [_bleManager writeStringValue:@"41" toCharacter:_write back:^(NSData *data) {
        NSString *hexString = data.description;
        NSLog(@"电量-->%@", hexString);
        hexString = [hexString stringByReplacingOccurrencesOfString:@"<" withString:@""];
        hexString = [hexString stringByReplacingOccurrencesOfString:@">" withString:@""];
        hexString = [hexString stringByReplacingOccurrencesOfString:@" " withString:@""];
        int power = 0;
        int dianya = 0;
        if (hexString.length<10) {
            // 无法获取电量
            
        } else {
            NSDateFormatter *dfm = [[NSDateFormatter alloc] init];
            dfm.dateFormat = @"HH:mm:ss";
            NSString *currentTime = [dfm stringFromDate:[NSDate date]];
            
            NSString *dianyaStr = [hexString substringWithRange:NSMakeRange(4, 4)];
            hexString = [hexString substringWithRange:NSMakeRange(8, 2)];
            
            power = [[self numberHexString:hexString] intValue];
            dianya = [[self numberHexString:dianyaStr] intValue];
            [_voltages addObject:[NSNumber numberWithInt:dianya]];
            [_powers addObject:[NSNumber numberWithInt:power]];
            [_times addObject:currentTime];
            [self.tableView reloadData];
        }
    }];
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self Test];
    });
}

- (void)Test {
    // 开始测量
    _testTime = 0;
    _logLabel.text = @"开始测量";
    [_bleManager writeStringValue:@"3100" toCharacter:_write back:^(NSData *data) {
        NSString *firstByte = @"";  // length = 2
        NSString *secondByte = @""; // length = 2
        NSString *thirdByte = @"";  // length = 2
        
        NSString *dataStr = data.description;
        dataStr = [dataStr stringByReplacingOccurrencesOfString:@" " withString:@""];
        dataStr = [dataStr stringByReplacingOccurrencesOfString:@"<" withString:@""];
        dataStr = [dataStr stringByReplacingOccurrencesOfString:@">" withString:@""];
        if (dataStr.length >= 2) {
            firstByte = [dataStr substringToIndex:2];
            if (dataStr.length >= 4) {
                secondByte = [dataStr substringWithRange:NSMakeRange(2, 2)];
                if (dataStr.length >= 6) {
                    thirdByte = [dataStr substringWithRange:NSMakeRange(4, 2)];
                }
            }
        }
        
        // 脉搏波数据
        if ([firstByte isEqualToString:@"32"]) {
            
//            NSLog(@"%@", dataStr);
#pragma mark - 获取脉搏波数据
            if ([secondByte isEqualToString:@"01"]) {
                if ([thirdByte isEqualToString:@"02"]) {
                    // 电量低
                    _logLabel.text = @"电量过低";
                    return;
                } else if ([thirdByte isEqualToString:@"03"]) {
                    // 测满 8000个点 ,自动停止测量
                    _logLabel.text = @"测满 8000个点 ,自动停止测量";
                    // 断开蓝牙设备
                    [_bleManager disconnectBle:_bleManager.peripheral];
                    return;
                }
                _logLabel.text = @"手指未放置在传感器上";
            } else if ([secondByte isEqualToString:@"02"]) {
                _logLabel.text = @"手指在测量过程中离开传感器";
            } else if ([secondByte isEqualToString:@"03"]) {
                // 传感器损坏
                _logLabel.text = @"传感器损坏";
            } else{
                _logLabel.text = @"测量中...";
            }
            
        }
    }];
}

// 停止测量
- (void)stopTest {
    _testTime ++;
    if (_testTime >= 60) {
        NSLog(@"停止测量---");
        _testTime = 0;
        // 断开蓝牙设备
        [_bleManager disconnectBle:_bleManager.peripheral];
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _powers.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    
    int power = [_powers[indexPath.row] intValue];
    int dianya = [_voltages[indexPath.row] intValue];
    NSString *currentTime = _times[indexPath.row];
    int index = [_indexs[indexPath.row] intValue];
    if (power > 0) {
        cell.textLabel.text = [NSString stringWithFormat:@"%@--第%d次电量:%d%%-%d", currentTime,index,power, dianya];
    } else {
        cell.textLabel.text = [NSString stringWithFormat:@"%@--第%d次测量电量失败", currentTime,index];
    }
    
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 44;
}

// 16进制转10进制
- (NSNumber *)numberHexString:(NSString *)aHexString
{
    // 为空,直接返回.
    if (nil == aHexString)
    {
        return nil;
    }
    
    NSScanner * scanner = [NSScanner scannerWithString:aHexString];
    unsigned long long longlongValue;
    [scanner scanHexLongLong:&longlongValue];
    
    //将整数转换为NSNumber,存储到数组中,并返回.
    NSNumber * hexNumber = [NSNumber numberWithLongLong:longlongValue];
    
    return hexNumber;
    
}


-(void)showAlertControllerWithMessage:(NSString *)message isBack:(BOOL)back{
    UIAlertController * alert = [UIAlertController alertControllerWithTitle:nil message:message preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction * okAction = [UIAlertAction actionWithTitle:@"我知道了" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        if (back) {
            [self.navigationController popViewControllerAnimated:YES];
        }
    }];
    [alert addAction:okAction];
    [self presentViewController:alert animated:YES completion:nil];
}


@end
