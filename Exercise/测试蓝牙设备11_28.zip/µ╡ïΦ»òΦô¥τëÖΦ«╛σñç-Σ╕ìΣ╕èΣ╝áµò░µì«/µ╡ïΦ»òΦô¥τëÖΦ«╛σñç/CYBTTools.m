//
//  CYBTTools.m
//  蓝牙demo
//
//  Created by 深圳前海全民健康科技股份有限公司 on 2017/6/2.
//  Copyright © 2017年 深圳前海全民健康科技股份有限公司. All rights reserved.
//

#import "CYBTTools.h"

//#import "AFNetworking.framework/AFNetworking"
//@import AFNetworking;
//#import "AFNetworking.h"
#import <AFNetworking/AFNetworking.h>
#import <CommonCrypto/CommonDigest.h>
//#import "QmjkPreferences.h"

#define CHUNK_SIZE 1024*8

@implementation CYBTTools

/**
 16进制字符串转NSData类型
 
 @param str 16进制字符串
 @return NSData
 */
+ (NSData *)hexToBytes:(NSString *)str {
    NSMutableData* data = [NSMutableData data];
    int idx;
    for (idx = 0; idx+2 <= str.length; idx+=2) {
        NSRange range = NSMakeRange(idx, 2);
        NSString* hexStr = [str substringWithRange:range];
        NSScanner* scanner = [NSScanner scannerWithString:hexStr];
        unsigned int intValue;
        [scanner scanHexInt:&intValue];
        [data appendBytes:&intValue length:1];
    }
    return data;
}
/**
 16进制字符串转NSData类型
 
 @return NSData
 */
+ (NSData *)dataFromHexString:(NSString *)hexString {
    const char *chars = [hexString UTF8String];
    long i = 0, len = hexString.length;
    
    NSMutableData *data = [NSMutableData dataWithCapacity:len / 2];
    char byteChars[3] = {'\0','\0','\0'};
    unsigned long wholeByte;
    
    while (i < len) {
        byteChars[0] = chars[i++];
        byteChars[1] = chars[i++];
        wholeByte = strtoul(byteChars, NULL, 16);
        [data appendBytes:&wholeByte length:1];
    }
    
    return data;
}


/**
 16进制字符串 -> 10进制字符串 -> （通过ASCII码）转换成字符串
 */
+ (NSString *)stringWithHexString:(NSString *)hexstring {
    NSString *result = @"";
    // 两个16进制字符转一个10进制数，再通过ASCII码转换成字符串
    int length = (int)hexstring.length;
    
    for (int i = 0; i < length; i += 2) {
        NSString *str = [hexstring substringWithRange:NSMakeRange(i, 2)];
        int ten = (int)strtoul([str UTF8String], 0, 16);
        // 10进制  根据ASCII码 转字符串
        result = [result stringByAppendingString:[NSString stringWithFormat:@"%C", (unichar)ten]];
    }
    
    return result;
}

/**
 去掉字符串中所有的大小写字母和空格并转换成int类型
 */
+ (int)intValueWithString:(NSString *)string {
    NSCharacterSet *setString = [NSCharacterSet characterSetWithCharactersInString:@"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ "];
    NSString *disposeString = [[NSString stringWithFormat:@"%@", string] stringByTrimmingCharactersInSet:setString];
    return [disposeString intValue];
}


+ (NSString *)getDeviceIdWithHexString:(NSString *)dataStr {
    
    if (dataStr.length < 30) {
        return @"";
    }
    // 设备id
    dataStr = [dataStr stringByReplacingOccurrencesOfString:@"<" withString:@""];
    dataStr = [dataStr stringByReplacingOccurrencesOfString:@">" withString:@""];
    dataStr = [dataStr stringByReplacingOccurrencesOfString:@" " withString:@""];
    // 1210 4359 0001 4744434e 17 08 01 0009 5de486
    dataStr = [dataStr substringWithRange:NSMakeRange(4, 26)];
    NSString *deviceId = @"";
    for (int i = 0; i < dataStr.length; i ++) {
        if (i == 0) { // 4359
            NSString *str = [CYBTTools stringWithHexString:[dataStr substringToIndex:4]];
            deviceId = [deviceId stringByAppendingFormat:@"%@",str];
        } else if (i == 3) { // 0001
            NSString *str = [dataStr substringWithRange:NSMakeRange(4, 4)];
            int value = [str intValue];
            if (value < 10) {
                str = [NSString stringWithFormat:@"0%d", value];
            } else {
                str = [NSString stringWithFormat:@"%d", value];
            }
            deviceId = [deviceId stringByAppendingFormat:@"%@ ",str];
        } else if (i == 7) {// 4744434e
            NSString *str1 = [CYBTTools stringWithHexString:[dataStr substringWithRange:NSMakeRange(8, 4)]];
            NSString *str2 = [CYBTTools stringWithHexString:[dataStr substringWithRange:NSMakeRange(12, 4)]];
            deviceId = [deviceId stringByAppendingFormat:@"%@ %@ ",str1, str2];
        } else if (i == 15) { // 17
            NSString *str = [dataStr substringWithRange:NSMakeRange(16, 2)];
            str = [NSString stringWithFormat:@"20%@", str];
            deviceId = [deviceId stringByAppendingFormat:@"%@ ",str];
        } else if (i == 17) { // 08
            NSString *str = [dataStr substringWithRange:NSMakeRange(18, 2)];
            int value = [str intValue];
            str = [NSString stringWithFormat:@"%d", value];
            deviceId = [deviceId stringByAppendingFormat:@"%@ ",str];
        } else if (i == 19) { // 01
            NSString *str = [dataStr substringWithRange:NSMakeRange(20, 2)];
            int value = [str intValue];
            str = [NSString stringWithFormat:@"%d", value];
            deviceId = [deviceId stringByAppendingFormat:@"%@ ",str];
        } else if (i == 21) { // 0009
            NSString *str = [dataStr substringWithRange:NSMakeRange(22, 4)];
            int value = [str intValue];
            str = [NSString stringWithFormat:@"%d", value];
            deviceId = [deviceId stringByAppendingString:str];
        }
    }

    return deviceId;
}


+ (NSString *)getFileMD5:(NSString *)path {
    
    NSFileHandle *handle = [NSFileHandle fileHandleForReadingAtPath:path];
    if( handle== nil ) return @"ERROR GETTING FILE MD5"; // file didnt exist
    
    CC_MD5_CTX md5;
    
    CC_MD5_Init(&md5);
    
    BOOL done = NO;
    while(!done)
    {
        NSData* fileData = [handle readDataOfLength:CHUNK_SIZE];
        
        CC_MD5_Update(&md5, [fileData bytes], (CC_LONG)[fileData length]);
        
        if( [fileData length] == 0 ) done = YES;
    }
    unsigned char digest[CC_MD5_DIGEST_LENGTH];
    CC_MD5_Final(digest, &md5);
    NSString* s = [NSString stringWithFormat: @"%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x",
                   digest[0], digest[1],
                   digest[2], digest[3],
                   digest[4], digest[5],
                   digest[6], digest[7],
                   digest[8], digest[9],
                   digest[10], digest[11],
                   digest[12], digest[13],
                   digest[14], digest[15]];
    return s;
}


@end
