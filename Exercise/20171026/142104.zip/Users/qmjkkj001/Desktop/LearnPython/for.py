#!/usr/bin/python
# Filename:for.py

for i in xrange(1,10):
	print i
else:
	print 'The for loop is over.'