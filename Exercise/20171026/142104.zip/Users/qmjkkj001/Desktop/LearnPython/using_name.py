# Filename: using_name.py

if __name__ == '__main__':
	print 'This is program is being run by itself'
else:
	print 'I am being imported from another module'