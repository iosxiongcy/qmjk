
def sayhi():
	print 'Hi, this is mymoudle speaking.'

version = 0.1