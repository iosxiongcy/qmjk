
import mymoudle

mymoudle.sayhi()
print 'Version', mymoudle.version