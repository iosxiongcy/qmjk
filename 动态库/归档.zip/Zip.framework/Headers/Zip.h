//
//  Zip.h
//  Zip
//
//  Created by Roy Marmelstein on 13/12/2015.
//  Copyright © 2015 Roy Marmelstein. All rights reserved.
//

@import Foundation;

//! Project version number for Zip.
FOUNDATION_EXPORT double ZipVersionNumber;

//! Project version string for Zip.
FOUNDATION_EXPORT const unsigned char ZipVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Zip/PublicHeader.h>


