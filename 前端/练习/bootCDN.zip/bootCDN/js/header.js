/**
 * Created by qmjkkj001 on 2017/11/28.
 */


// console.log(typeof ($('#search-input')));
//
// $('#search-input').bind('oninput propertychange change', function (event) {
//     console.log($('#search-input').val());
//     alert(1);
// })
